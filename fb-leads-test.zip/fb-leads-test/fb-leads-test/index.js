require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.json());

const VERIFY_TOKEN = process.env.VERIFY_TOKEN || 'rahul_fb_token';


app.get('/webhook', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];

  if (mode === 'subscribe' && token === VERIFY_TOKEN) {
    console.log('WEBHOOK_VERIFIED');
    res.status(200).send(challenge);
  } else {
    res.sendStatus(403);
  }
});

// Receive events (POST)
app.post('/webhook', (req, res) => {
  try {
    console.log('--- Received webhook POST ---');
    console.log(JSON.stringify(req.body, null, 2));


    if (req.body && req.body.entry) {
      req.body.entry.forEach(entry => {
        if (entry.changes) {
          entry.changes.forEach(change => {
            if (change.field === 'leadgen' || (change.value && change.value.leadgen_id)) {
              console.log('New lead event detected:', change.value);
              // TODO: Save to DB or process lead
            } else {
              console.log('Other change:', change);
            }
          });
        }
      });
    }

    res.status(200).send('EVENT_RECEIVED');
  } catch (err) {
    console.error('Error handling webhook POST', err);
    res.sendStatus(500);
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Webhook server listening on port ${port}`));
